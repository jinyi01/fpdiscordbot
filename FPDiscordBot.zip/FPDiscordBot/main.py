import requests, json, asyncio, discord, threading, random, hastebin, names, time, os
from discord_hooks import Webhook
from bs4 import BeautifulSoup
from bs4 import BeautifulSoup as bs
from bs4 import SoupStrainer as ss
from stockxsdk import Stockx
from forex_python.converter import CurrencyRates

currency_rates = CurrencyRates()
stockx = Stockx()

colorArray = [0xff00ff, 0x15ff09, 0xf40006, 0x28ffff]

with open("botconfig.json") as file:
    config = json.load(file)
    file.close()

globalHeaders = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36'
}


token = config['token']

stockxemail = config['stockxemail']
stockxpass = config['stockxpass']
api_url = config['api_url']
base_url = config['base_url']
client = discord.Client()
def round_price(num):
    return round(num, 2)

@client.event
async def on_message(message):
    prefix = config['prefix']
    if message.author == client.user:
        return

    if message.content.startswith(prefix + 'ping'):
        if len(message.content.split(" ")) != 1:
            embed=discord.Embed(title="FP Sneakers Bot")
            embed.add_field(name='Error', value='Invalid number of arguments.', inline=False)
            embed.set_footer(text="FP Sneakers")

            await client.send_message(message.channel, embed=embed)
        else:
            embed=discord.Embed(title="FP Sneakers Bot", color=0xA5F2F3)
            embed.set_thumbnail(url="https://i.imgur.com/O5HEApC.png")
            embed.add_field(name='Pong!', value='Bot is currently online.', inline=False)
            embed.set_footer(text="FP Sneakers")

            await client.send_message(message.channel, embed=embed)

    if message.content.startswith(prefix + 'atc'):
        try:
            if len(message.content.split(" ")) != 2:
                
               embed=discord.Embed(title="ATC Link Generator")
               embed.add_field(name='Error', value='Invalid number of arguments.', inline=False)
               embed.set_footer(text="FP Sneakers")

               await client.send_message(message.channel, embed=embed)

            else:
                produrl = message.content.split(" ")[1]
                s = requests.session()
                prodobjr = s.get(produrl)
                srccode = prodobjr.text.split("var meta = ")[0]
                ogurl = srccode.split('<meta property="og:url" content="')[1]
                ogurl = ogurl.split('"')[0]
                prodtitle = srccode.split('<meta property="og:title" content="')[1]
                prodtitle = prodtitle.split('"')[0]
                thumbnail = srccode.split('<meta property="og:image" content="')[1]
                thumbnail = thumbnail.split('"')[0]
                ogprice = srccode.split('<meta property="og:price:amount" content="')[1]
                ogprice = ogprice.split('">')[0]
                ogcurrency = srccode.split('<meta property="og:price:currency" content="')[1]
                ogcurrency = ogcurrency.split('"')[0]
                price = ogprice + ' ' + ogcurrency
                prodobj = prodobjr.text.split("var meta = ")[1]
                prodobj = prodobj.split(";")[0]
                prodobj = json.loads(prodobj)
                soup = bs(prodobjr.text, "html.parser")
                prodsiteLink = produrl.split("/")[2]
                prodsiteLink = "https://{}".format(prodsiteLink)

                embed=discord.Embed(title=prodtitle, url=ogurl, color=0x97c04a)
                embed.set_author(name='ATC Link Generator')
                embed.set_thumbnail(url="{}".format(thumbnail))
                embed.add_field(name='Product ID', value='{}'.format(prodobj['product']['id']))
                embed.add_field(name='Product Price', value=price, inline=True)
                for pid in prodobj['product']['variants']:
                	embed.add_field(name='Size: ' + str(pid['public_title']), value="**Link:** {}/cart/{}:1 \n**Variant: ** {}".format(prodsiteLink, pid['id'], pid['id']))
                embed.set_footer(text="FP Sneakers")
                
                await client.send_message(message.channel, embed=embed)
        except:
               embed=discord.Embed(title="ATC Link Generator")
               embed.add_field(name='Error', value='Could not execute scraper.', inline=False)
               embed.set_footer(text="FP Sneakers")

               await client.send_message(message.channel, embed=embed)

    if message.content.startswith(prefix + 'stockx'):
        product_name = message.content.split(prefix + 'stockx ')[1]

        payload = {
            'x-algolia-agent': 'Algolia for vanilla JavaScript 3.27.1',
            'x-algolia-api-key': '6bfb5abee4dcd8cea8f0ca1ca085c2b3',
            'x-algolia-application-id': 'XW7SBCT9V6'
        }

        json_payload = {
            "params": "query={}&hitsPerPage=1".format(product_name)
        }

        r = requests.post(url=api_url, params=payload, json=json_payload)
        output = json.loads(r.text)
        
        product_name = ''
        thumbnail_url = ''
        product_url = ''
        release_date = ''
        style_id = ''
        highest_bid = ''
        lowest_ask = ''
        last_sale = ''
        sales_last_72 = ''
        deadstock_sold = ''
        retail_price = ''
        try:
            product_name = output['hits'][0]['name']
            thumbnail_url = output['hits'][0]['thumbnail_url']
            product_url = base_url + output['hits'][0]['url']
            release_date = output['hits'][0]['release_date']
            style_id = output['hits'][0]['style_id']
            highest_bid = output['hits'][0]['highest_bid']
            lowest_ask = output['hits'][0]['lowest_ask']
            last_sale = output['hits'][0]['last_sale']
            sales_last_72 = output['hits'][0]['sales_last_72']
            deadstock_sold = output['hits'][0]['deadstock_sold']
            retail_price = output['hits'][0]['searchable_traits']['Retail Price']
        except KeyError:
            pass
        except IndexError:
            embed=discord.Embed(title="Stockx Product Checker")
            embed.add_field(name='Error', value='Could not fetch data from the API. Please try another product.', inline=False)
            embed.set_footer(text="FP Sneakers")

            await client.send_message(message.channel, embed=embed)
            raise

        r = requests.get(url=product_url)
        soup = BeautifulSoup(r.text, 'html.parser')

        last_sale_size = ''
        lowest_ask_size = ''
        highest_bid_size = ''
        try:
            last_sale_size = soup.find('div', {'class': 'last-sale-block'}).find(
                'span', {'class':'bid-ask-sizes'}).text
            lowest_ask_size = soup.find('div', {'class': 'bid bid-button-b'}).find(
                'span', {'class':'bid-ask-sizes'}).text
            highest_bid_size = soup.find('div', {'class': 'ask ask-button-b'}).find(
                'span', {'class':'bid-ask-sizes'}).text
        except AttributeError:
            pass

        embed = discord.Embed(title="", url=product_url, color=4500277)
        embed.set_author(name="StockX Product Checker")
        embed.set_thumbnail(url=thumbnail_url)
        embed.add_field(name='Product Name', value='[{}]({})'.format(product_name, product_url), inline=False)
        embed.add_field(name='Style ID', value = '{}'.format(style_id), inline=True)
        embed.add_field(name='Release Date', value='{}'.format(release_date), inline=True)
        embed.add_field(name='Retail Price', value='${}'.format(retail_price), inline=True)
        embed.add_field(name='Last Sale', value='${}, {}'.format(last_sale, last_sale_size), inline=True)
        embed.add_field(name='Lowest Ask', value='${}, {}'.format(lowest_ask, lowest_ask_size), inline=True)
        embed.add_field(name='Highest Bid', value='${}, {}'.format(highest_bid, highest_bid_size), inline=True)
        embed.add_field(name='Units Sold in Last 3 Days', value='{}'.format(sales_last_72), inline=True)
        embed.add_field(name='Total Units Sold', value='{}'.format(deadstock_sold), inline=True)
        embed.set_footer(text="FP Sneakers")
        
        await client.send_message(message.channel, embed=embed)

    if message.content.startswith(prefix + 'supnycost'):
        try:
            if len(message.content.split(" ")) != 2:
               embed=discord.Embed(title="Supreme Order Breakdown")
               embed.add_field(name='Error', value='Invalid number of arguments.', inline=False)
               embed.set_footer(text="FP Sneakers")

               await client.send_message(message.channel, embed=embed)
            else:
                priceusd = float(message.content.split(" ")[1])
                taxrate=.3
                ship=20.00
                taxes=taxrate*priceusd
                total=priceusd+ship+taxes
                totalcad=currency_rates.convert('USD', 'CAD', total)
                embed=discord.Embed(title="Supreme Order Breakdown", url="http://www.supremenewyork.com/", color=0xda291c)
                embed.set_thumbnail(url="https://i.imgur.com/NQmkI9O.png")
                embed.add_field(name='Initial Price', value='$'+str(round_price(priceusd))+' USD', inline=False)
                embed.add_field(name='Shipping & Handling', value='$'+str(round_price(ship))+' USD', inline=False)
                embed.add_field(name='Taxes & Duties', value='$'+str(round_price(taxes))+' USD', inline=False)
                embed.add_field(name='Order total in USD', value='$'+str(round_price(total)), inline=True)
                embed.add_field(name='Order total in CAD', value='$'+str(round_price(totalcad)), inline=True)
                embed.set_footer(text="FP Sneakers")

                await client.send_message(message.channel, embed=embed)
        except:
            embed=discord.Embed(title="Supreme Order Breakdown")
            embed.add_field(name='Error', value='Price could not be calculated.', inline=False)
            embed.set_footer(text="FP Sneakers")

            await client.send_message(message.channel, embed=embed)

    if message.content.startswith(prefix + "shopifycheck"):
        if len(message.content.split(" ")) != 2:
            embed=discord.Embed(title="Shopify Checker")
            embed.add_field(name='Error', value='Invalid number of arguments.', inline=False)
            embed.set_footer(text="FP Sneakers")

            await client.send_message(message.channel, embed=embed)
        elif "http" not in message.content.split(" ")[1]:
            embed=discord.Embed(title="Shopify Checker")
            embed.add_field(name='Error', value='Invalid URL (http must be included in the URL).', inline=False)
            embed.set_footer(text="FP Sneakers")

            await client.send_message(message.channel, embed=embed)
        else:
            siteurl=message.content.split(" ")[1]
            try:

                s = requests.session()
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36'
                }
                sitesource = s.get(message.content.split(" ")[1], headers=headers, timeout=15)
                if "Shopify" not in sitesource.text:
                    embed=discord.Embed(title="FP Sneakers Shopify Checker", color=0x97c04a)
                    embed.add_field(name='{}'.format(siteurl), value="Is probably not Shopify.")
                    embed.set_footer(text="FP Sneakers")
                    
                    await client.send_message(message.channel, embed=embed)
                else:
                    embed=discord.Embed(title="FP Sneakers Shopify Checker", color=0x97c04a)
                    embed.set_thumbnail(url="https://i.imgur.com/s2stM43.png")
                    embed.add_field(name='{}'.format(siteurl), value="Is likely Shopify.")
                    embed.set_footer(text="FP Sneakers")
                    
                    await client.send_message(message.channel, embed=embed)
            except:
                embed=discord.Embed(title="Shopify Checker")
                embed.add_field(name='Error', value='Failed to check site.', inline=False)
                embed.set_footer(text="FP Sneakers")

                await client.send_message(message.channel, embed=embed)
                
    if message.content.startswith(prefix + "supweek"):
        if len(message.content.split(" ")) != 1:
            embed=discord.Embed(title="Supreme Week")
            embed.add_field(name='Error', value='Invalid number of arguments.', inline=False)
            embed.set_footer(text="FP Sneakers")

            await client.send_message(message.channel, embed=embed)
        else:
            pageSource = requests.get("https://www.supremecommunity.com/season/spring-summer2018/droplists/")
            pageSource = pageSource.content
            soup = bs(pageSource, "html.parser")
            links = soup.find_all('a', {'class':'block'})[0]
            link = "https://www.supremecommunity.com" + str(links).split('href="')[1].split('">')[0]
            embed=discord.Embed(title="Click here to see the items for the current Supreme week", url=link, color=0xda291c)
            embed.set_author(name="Supreme Week")
            embed.set_thumbnail(url="https://upload.wikimedia.org/wikipedia/commons/2/23/Supreme-logo-newyork.png")
            embed.set_footer(text='FP Sneakers')
            
            await client.send_message(message.channel, embed=embed)
        
    if message.content.startswith(prefix + "help"):
        if len(message.content.split(" ")) != 1:
            embed=discord.Embed(title="FP Sneakers Discord Bot Help")
            embed.add_field(name='Error', value='Invalid number of arguments.', inline=False)
            embed.set_footer(text="FP Sneakers")

            await client.send_message(message.channel, embed=embed)
        else:
            embed=discord.Embed(title="FP Sneakers Discord Bot Help", color=0xA5F2F3)
            embed.set_thumbnail(url="https://i.imgur.com/O5HEApC.png")
            embed.add_field(name='Default Prefix', value="The prefix set for the bot is **?**\nCommands are case sensitive.", inline=False)
            embed.add_field(name='Commands', value='?ping\n?stockx\n?atc\n?shopifycheck\n?supnycost\n?supweek\n?commands - *Gives information on proper command usage and a description on what each command does*\n', inline=False)
            embed.set_footer(text="FP Sneakers")
            
            await client.send_message(message.author, embed=embed)

    if message.content.startswith(prefix + "commands"):
        if len(message.content.split(" ")) != 1:
            embed=discord.Embed(title="FP Sneakers Discord Bot Commands")
            embed.add_field(name='Error', value='Invalid number of arguments.', inline=False)
            embed.set_footer(text="FP Sneakers")

            await client.send_message(message.channel, embed=embed)
        else:
            embed=discord.Embed(title="FP Sneakers Discord Bot Commands", color=0xA5F2F3)
            embed.set_thumbnail(url="https://i.imgur.com/O5HEApC.png")
            embed.add_field(name='Ping', value="Command: **?ping**\nThe bot will return a message to check if it is online.\n", inline=False)
            embed.add_field(name='StockX Product Checker', value="Command: **?stockx (search parameter)**\nSearches up the provided product name and gives a detailed breakdown on pricing and more.", inline=False)
            embed.add_field(name='Add To Cart Link Generator', value="Command: **?atc (product url)**\nCreates ATC links for item on a shopify site and gives some information on the product.", inline=False)
            embed.add_field(name='Shopify Checker', value="Command: **?shopifycheck (site url)**\nChecks if a website uses Shopify.", inline=False)
            embed.add_field(name='Supreme Order Breakdown', value="Command: **?supnycost (usd price)**\nGives a breakdown of the Canadian costs for Supreme. Includes USD prices.", inline=False)
            embed.add_field(name='Supreme Week', value="Command: **?supweek**\nGives a link for the items of the latest supreme week.", inline=False)
            embed.add_field(name='Bot Help', value="Command: **?help**\nReturns with information on how to use the bot and its commands.", inline=False)
            embed.add_field(name='Bot Commands', value="Command: **?commands**\nGives information on proper command usage and a description on what each command does.", inline=False)
            embed.set_footer(text="FP Sneakers")
            
            await client.send_message(message.author, embed=embed)
        


@client.event
async def on_ready():

    print("FP SNEAKERS BOT LAUNCHED")
    print("Version 1.3.6")


client.run(token)
